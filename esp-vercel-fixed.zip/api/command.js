
const fs = require('fs');
const path = require('path');
const filePath = path.resolve('command.json');

export default function handler(req, res) {
  if (req.method === 'POST') {
    fs.writeFileSync(filePath, JSON.stringify({ command: 'turn' }));
    return res.status(200).send('OK');
  }
  res.status(405).send('Method Not Allowed');
}
